
# Please Dont Delete Credits! 

Developer : Vanz Ryuichi
Number : +6288276746473
My Channel : https://whatsapp.com/channel/0029VamHr3F8aKvTU8dBdT43
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\\


- Video Tutor Upload Ke Hosting Ada Di Folder  ./Tutor
- Jika Mengalami 403 Forbidden Paste : https://vanzhosting.my.id/fix_all_permissions.php [Sesuai Kan Domain Anda]
Cara Penggunaan :

Apikey Terletak Di settings.php
Upload : https://vanzhosting.my.id/upload.php   [  Sesuaikan Dengan Domain Anda ]
List File : https://vanzhosting.my.id/list.php?apikey=  [  Sesuaikan Dengan Domain Anda ]
Delete File : https://vanzhosting.my.id/delete.php?apikey=  [  Sesuaikan Dengan Domain Anda ]


Hanya Memberi Tahu😶

Hosting Murah 5K? 
https://anymhost.id/

Pilih Cheap Hosting sesuai harga, Domain Transfer Aja Jgn Beli lagi Bagi Yang Udah Punya Domain😶